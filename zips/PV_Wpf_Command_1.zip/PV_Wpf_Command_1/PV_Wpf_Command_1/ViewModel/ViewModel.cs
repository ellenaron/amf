﻿using PV_Wpf_Command_1.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace PV_Wpf_Command_1.ViewModel
{
    internal class ViewModel : ViewModelBase
    {
        public ICommand ShowMessageBoxCommand { get; set; }
        public ViewModel() 
        {
            ShowMessageBoxCommand = new RelayCommand(_ => ShowMessageBox());        
        }
        private void ShowMessageBox()
        {
            MessageBox.Show("Hello World!");
        }
    }
}
